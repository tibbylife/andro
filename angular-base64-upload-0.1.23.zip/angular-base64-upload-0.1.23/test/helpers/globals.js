
// singleton variables
var FILE_READER_EVENTS = ['onabort', 'onerror', 'onloadstart', 'onloadend', 'onprogress', 'onload'];
var $ROOTSCOPE, $COMPILE, $INJECTOR;














